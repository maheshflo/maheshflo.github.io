import java.util.*;

class ATM {
    int pin = 1234;
    float Balance;
    Scanner sc = new Scanner(System.in);
    public void checkPin() {
        System.out.print("Enter Your Pin: ");
        int Pin = sc.nextInt();
        if(Pin == pin) {
            menu();
        }
        else {
            System.out.println("Invalid Pin !!.");
            menu();
        }
    }
    public void menu()
    {
        System.out.println("1. Check Balance.");
        System.out.println("2. Deposit.");
        System.out.println("3. Withdrawal.");
        System.out.println("4. Reset Pin.");
        System.out.println("5. Exit.");
        System.out.print("Enter Your Choice: ");
        int opt = sc.nextInt();

        if(opt == 1){
            checkBalance();
        }
        else if (opt == 2) {
            deposit();
        }
        else if (opt == 3) {
            withdrawal();
        } else if (opt == 4) {
            change();

        } else if (opt == 5) {
            System.out.println("Your Transactions are successful. Thank You, Visit Again..");
            return;
        }
        else {
            System.out.println("Please Enter a Valid Pin.!!");
        }
    }
    public void checkBalance(){
        System.out.println("Your Balance is "+Balance+" .");
        menu();
    }
    public void deposit(){
        System.out.print("Enter Amount to Deposit: ");
        float amount = sc.nextFloat();
        Balance = Balance + amount;
        System.out.println("Money Deposited Successfully..");
        menu();
    }
    public void withdrawal(){
        System.out.print("Enter Your Amount to Withdrawal: ");
        float amount = sc.nextFloat();
        if(amount>Balance) {
            System.out.println("Insufficient Balance..!!");
            menu();
        }
        else{
            Balance = Balance - amount;
            System.out.println("Money Withdrawn Successful..");
            menu();
        }
    }
    public void change(){
        System.out.print("Enter Old Pin: ");
        pin = sc.nextInt();
        if(pin == pin) {
            System.out.print("Enter New Pin: ");
            int newpin = sc.nextInt();
            System.out.print("Confirm Pin: ");
            pin = sc.nextInt();
            pin = newpin;
            menu();
        }
        else{
            System.out.println("Please Re-Enter Your Older Pin..");
        }


    }

}
public class Main {
    public static void main(String[] args) {
        System.out.println("<------------------------------------------------------------------ATM Machine Using Java (OOPS)------------------------------------------------------------------>");
        ATM obj = new ATM();
        obj.checkPin();
    }
}
